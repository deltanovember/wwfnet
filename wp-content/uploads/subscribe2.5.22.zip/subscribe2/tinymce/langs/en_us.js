// US lang variables

tinyMCE.addToLang('subscribe2quicktags',{
subscribe2 : 'Embed Subscribe2 token'
});
